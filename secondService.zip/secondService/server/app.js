var grpc = require("@grpc/grpc-js");
var protoLoader = require("@grpc/proto-loader");
var PROTO_PATH = __dirname + "/protos/emergencychat.proto";
var packageDefinition = protoLoader.loadSync(PROTO_PATH);
var emergencychat_proto = grpc.loadPackageDefinition(packageDefinition).emergencychat;

var clients = {
}

function sendMessage(call) {
  call.on('data', function(emergencychat_message) {

    if (!(emergencychat_message.name in clients)) {
      clients[emergencychat_message.name] = {
        name: emergencychat_message.name,
        call: call
      }
    }

    for (var client in clients) {
      clients[client].call.write(
        {
          name: emergencychat_message.name,
          message: emergencychat_message.message
        }
      )
    }
  });
  call.on('end', function() {
    call.end();
  });

  call.on('error', function(e) {
    console.log(e)
  });

}

var server = new grpc.Server();
server.addService(emergencychat_proto.EmergencyChatService.service, {
  sendMessage:sendMessage
})
server.bindAsync("0.0.0.0:40000", grpc.ServerCredentials.createInsecure(), function() {
  server.start()
})