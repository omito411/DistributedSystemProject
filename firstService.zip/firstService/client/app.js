var grpc = require("@grpc/grpc-js")
var protoLoader = require("@grpc/proto-loader")
var PROTO_PATH = __dirname + "/protos/emergencyServce.proto"
var packageDefinition = protoLoader.loadSync(PROTO_PATH)
var emergencyServce_proto = grpc.loadPackageDefinition(packageDefinition).emergencyServce


var client = new emergencyServce_proto.Emergency(
    "localhost:40000",
    grpc.credentials.createInsecure()
);
  
client.requestEmergency({ 'id': -1, 'emergency': 'Fire' }, (err, response) => {
	if (err) {
		console.log(err);
	} else {
		console.log(`From server`, JSON.stringify(response));
	}
});

client.readEmergency({ 'id': 1 }, (err, response) => {
	if (err) {
		console.log(err);
	} else {
		console.log(`From server`, JSON.stringify(response));
	}
});

client.readEmergencies(null, (err, response) => {
	if (err) {
		console.log(err);
	} else {
		console.log(`From server`, JSON.stringify(response));
	}
});