var grpc = require("@grpc/grpc-js")
var protoLoader = require("@grpc/proto-loader")
var PROTO_PATH = __dirname + "/protos/emergencyServce.proto"
var packageDefinition = protoLoader.loadSync(PROTO_PATH
)
var emergencyServce_proto = grpc.loadPackageDefinition(packageDefinition).emergencyServce

var server = new grpc.Server();
server.addService(emergencyServce_proto.Emergency.service, {
	'requestEmergency': requestEmergency,
	'readEmergency': readEmergency,
	'readEmergencies': readEmergencies,
});

server.bindAsync('0.0.0.0:40000', grpc.ServerCredentials.createInsecure(), () => {
	console.log("Server running at http://127.0.0.1:40000");
	server.start();
}); // our sever is insecure, no ssl configuration


// Uhm, this is going to mirror our database, but we can change it to use an actual database.
var emergencies = [];

function requestEmergency(call, callback) {
	var emergency = call.request.emergency;
	var emergencyObject = {
		'id': emergencies.length + 1,
		'emergency': emergency,
	};
	emergencies.push(emergencyObject);
	callback(null, emergencyObject);
}

function readEmergency(call, callback) {
	var id = call.request.id;
	var emergency = emergencies.find((emergency) => emergency.id === id);
	callback(null, emergency);
}

function readEmergencies(call, callback) {
	callback(null, { emergencies: emergencies });
}



